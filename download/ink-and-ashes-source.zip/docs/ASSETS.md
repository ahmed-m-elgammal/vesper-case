# Ink & Ashes — Art & Audio Asset List

## 1. Room layers (SVG → rasterized once by Phaser, cached)

All room layers share the canvas `2400 x 900` (world units; camera shows 1600x900 at zoom 0.8). Hand-inked vector art: paper base `#f4ecdb`, ink `#2e2a33`, wobble via `feTurbulence` displacement (baseFrequency 0.011/0.014, scale ~7), watercolor washes as blurred ellipses.

| File | Layer | scrollFactor | Contents |
|---|---|---|---|
| `public/art/hall_bg.svg` | background | 0.82 | far wall, wallpaper, wainscot, front door + transom, parlour door, fox engraving, staircase, under-stair passage, ceiling beam |
| `public/art/hall_mid.svg` | middle | 1.00 | coat pegs (mac/oilskin/raincoat), umbrella stand (one dry umbrella), hall table + ledger + mail tray, grandfather clock (stopped 10:47), doormat (two print sets), horn button on bottom step, lamplight pools |
| `public/art/hall_fg.svg` | foreground | 1.18 | doorway post, vignette, dust motes, cobweb |
| `public/art/parlour_bg.svg` | background | 0.82 | panelled wall, hearth (stone, mantel, cold ember bed + fresh burn patch), fire tools, rain window + curtains, garden door, fox engraving |
| `public/art/parlour_mid.svg` | middle | 1.00 | wing chair + slumped Edmund (tasteful), side table + tumbler, writing desk + banker's lamp + manuscript + open drawer (sketch boards), drinks tray + dosed decanter, fallen mantel clock (11:38), fender, sideboard + scissors, rug + diamond-tread print, garden-door bolt (off, scratched) |
| `public/art/parlour_fg.svg` | foreground | 1.18 | vignette, dust motes, smoke wisp, near curtain edge |
| `public/art/kitchen_bg.svg` | background | 0.82 | whitewashed brick, rain window over the sink, tiled splash band, dark garden beyond the garden door, quarry-tile floor + stone flags in the vestibule |
| `public/art/kitchen_mid.svg` | middle | 1.00 | dresser + plate shelves + open rounds book + flour bin, cast-iron range (hotplates, ovens, warming shelf with the burnt loaf + kettle), hanging pans, scrubbed table + bowl + jug, wall shelf + the wireless (still switched on), pantry door ajar + hurricane lantern (oil to the mark, soot halo, glow), garden door + bolt plate, wet diamond-tread prints crossing the flags |
| `public/art/kitchen_fg.svg` | foreground | 1.18 | passage shadow, hanging herb strings + onion string, vestibule post, vignette |
| `public/art/landing_bg.svg` | background | 0.82 | wallpaper, picture rail, stair-well dark, rain window, attic-rise shadow, floorboards |
| `public/art/landing_mid.svg` | middle | 1.00 | descending stair flight (runner + worn lanes + wax drips on the twelfth step), Peggy's door, sill shelf + tonic bottle + rinsed inverted glass, window seat, Edmund's door, bathroom door, linen cupboard, attic stair rising + taped attic door |
| `public/art/landing_fg.svg` | foreground | 1.18 | balustrade + newel silhouette, attic-rise shadow, vignette |
| `public/art/hub.svg` | hub map | — | dollhouse cutaway `1920 x 1000`: attic studio, three rooms + landing above, hall/parlour/kitchen/study at ground, cellar + laundry below, tree, rain, padlock glyphs on locked plates |
| `public/art/plan.svg` | prologue | — (DOM) | floor plan `900 x 620` with room labels + act locks |

## 2. Close-up insets (inline SVG in the DOM, `800 x 600`)

Pencil-inset style: paper card frame, wobble ink, cross-hatch, Caveat annotations. Reused as notebook thumbnails.

| File | Clue |
|---|---|
| `public/art/closeups/cu_clock.svg` | The Stopped Clock (10:47) |
| `public/art/closeups/cu_umbrella.svg` | The Dry Umbrella |
| `public/art/closeups/cu_coats.svg` | The Coat Pegs (empty fourth peg) |
| `public/art/closeups/cu_doormat.svg` | Prints on the Mat |
| `public/art/closeups/cu_button.svg` | A Horn Button |
| `public/art/closeups/cu_ledger.svg` | The House Ledger (handwritten entries) |
| `public/art/closeups/cu_letter.svg` | The Sealed Letter (will instructions) |
| `public/art/closeups/cu_memoir.svg` | The Confession (whiskey stain, pp. 40–43 gap) |
| `public/art/closeups/cu_slip.svg` | The Torn Slip ("for H.M. — before Monday") |
| `public/art/closeups/cu_body.svg` | Edmund in the Wing Chair (dignified, no gore) |
| `public/art/closeups/cu_pills.svg` | His Heart Drops (Dr. H. Marsh label) |
| `public/art/closeups/cu_glass.svg` | The Nightcap Glass (film ring) |
| `public/art/closeups/cu_decanter.svg` | The Decanter (film at shoulder) |
| `public/art/closeups/cu_ash.svg` | Ash at the Ember Edge (purple petals, magnifier circle) |
| `public/art/closeups/cu_mantel.svg` | The Fallen Mantel Clock (11:38) |
| `public/art/closeups/cu_sketches.svg` | The Fox Studies (forged originals, verso note) |
| `public/art/closeups/cu_gardendoor.svg` | The Garden Door Bolt (off, fresh scratches) |
| `public/art/closeups/cu_print.svg` | A Ghost of a Print (diamond tread, 7–8) |
| `public/art/closeups/cu_scissors.svg` | Sewing Scissors |
| `public/art/closeups/cu_loaf.svg` | The Burnt Loaf (blackened crust on the sheet) |
| `public/art/closeups/cu_lantern.svg` | The Pantry Lantern (oil to the mark, soot halo) |
| `public/art/closeups/cu_radio.svg` | The Wireless (amber dial lit, switch left on) |
| `public/art/closeups/cu_flags.svg` | Wet Prints on the Flags (diamond tread, in and out) |
| `public/art/closeups/cu_ledgerpage.svg` | The Kitchen Rounds Book (10:35 → 11:30 entries) |
| `public/art/closeups/cu_runner.svg` | The Worn Runner (habit's lanes + wax drips) |
| `public/art/closeups/cu_tonic.svg` | The Tonic Glass (rinsed, upside down, dry ring) |

## 2b. People portraits (conversation + notebook)

All 800x600 inline SVGs (paper, wobble filter, washes), shown cropped in the conversation sheet and the notebook People tab:

| File | Subject |
|---|---|
| `public/art/people/colette.svg` | Colette Beaumont -- housekeeper (bun, apron, flour dust) |
| `public/art/people/tobias.svg` | Tobias Grimm -- apprentice (tousled hair, pencil behind ear, ink stains) |
| `public/art/people/peggy.svg` | Margaret 'Peggy' Vesper-Croft -- the niece (pinned hair, pearls, mourning dress) |

Room-scene people figures are engine-drawn (pencil silhouette tinted with the suspect's palette colour) at the `rooms.json` `people[].spot` rects.

## 3. UI chrome

- **Fonts** (bundled via `@fontsource`, OFL): `Caveat 500/700` (handwriting), `Special Elite 400` (typewriter/case file), `Crimson Pro 400/400i/600/700` (body serif).
- **PWA icons** (generated by `scripts/gen_icons.py`, PIL): `public/icons/icon-192.png`, `public/icons/icon-512.png`, `public/icons/maskable-512.png` — magnifier-on-paper motif.
- **Textures**: none (no sprite sheets needed for Build One — SVG layers rasterize directly). Budget per room ≈ 3 layers × 8.6 MB decoded, released on scene shutdown.

## 4. Audio plan (Milestone 6 — not shipped in Build One)

The engine ships an audio-off config (`audio: { noAudio: true }`) with the "Tap to begin" gate and volume/subtitle settings already in place. Planned manifest:

| Filename | Role | Loop? | Format |
|---|---|---|---|
| `audio/music_parlour.webm` (+ .m4a) | soft jazz/piano loop | yes | 96 kbps mono, ~2 min |
| `audio/amb_rain.webm` | rain bed | yes | looped |
| `audio/amb_thunder_01..03.webm` | one-shots | no | randomised pitch |
| `audio/clock_tick.webm` | near clocks | yes | quiet |
| `audio/footsteps_wood_carpet_stone.webm` | per surface | no | 3 sets |
| `audio/sfx_paper_01..02.webm` | page turns / notebook | no | |
| `audio/sfx_pencil_scratch.webm` | clue collected | no | |
| `audio/sfx_door_creak.webm`, `sfx_gate_accept.webm`, `sfx_gate_fail.webm` | transitions & gates | no | |

Subtitles fire from scene events already (`[rain, distant thunder]`, `[entrance hall — rain on the glass]`).

## 5. Size budget

| Bundle | Budget | Actual (Build One) |
|---|---|---|
| per-room art (SVG source) | < 5 MB | ~0.09 MB |
| JS (gzip) | < 1.5 MB | ~0.45 MB (Phaser dominates) |
| fonts | < 0.5 MB | ~0.3 MB |
